import { Injectable,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {
    this.getPokemon();
}
ngOnInit(){
  this.getPokemon();

}
getPokemon(){
    let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
   // subscribe to the Observable and provide the code we would like to do with our data from the response
      bulbasaur.subscribe(data => console.log("Got our tasks!", data));
      console.log("hi");
   }
}